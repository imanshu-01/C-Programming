# CPP PROGRAMMING 
# NUMBER-GUESSING-GAME

Task1

Create a program that generates a random number and asks the
user to guess it. Provide feedback on whether the guess is too
high or too low until the user guesses the correct number.
