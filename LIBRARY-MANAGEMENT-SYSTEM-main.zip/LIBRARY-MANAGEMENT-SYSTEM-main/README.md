# CPP PROGRAMMING WITH CODSOFT
# LIBRARY-MANAGEMENT-SYSTEM

Task5

Develop a system to manage books, borrowers, and transactions in a library.

Book Database: Store book information (title, author, ISBN) in a
database.
Book Search: Allow users to search for books based on title, author, or
ISBN.
Book Checkout: Enable librarians to check out books to borrowers.
Book Return: Record book returns and update availability status.
Fine Calculation: Implement a fine calculation system for overdue
books.
User Interface: Design a user-friendly interface for easy interaction.
