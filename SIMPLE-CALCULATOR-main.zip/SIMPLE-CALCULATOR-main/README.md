# CPP PROGRAMMING
# SIMPLE-CALCULATOR

Task-2

Develop a calculator program that performs basic arithmetic
operations such as addition, subtraction, multiplication, and
division. Allow the user to input two numbers and choose an
operation to perform.

Hello connections, I am thrilled to announce that I have recently completed my second task of c ++ programming internship with #codsoft.
Task Details
Task name: SIMPLE CALCULATOR
code editor: Visual studio code 
#Codsoft #cpp #programming
CodSoft
